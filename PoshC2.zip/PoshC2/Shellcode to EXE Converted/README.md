Shellcode files converted from .bin to exe.
